#include <stdio.h>
#include <stdlib.h>
#include "MiniAiff.h"


#define CHUNK_SIZE 8192

int main(void)
{
	int ret = 0;

#ifdef MAC_VERSION
	char inFileName[] = "../../blerp.aiff";
#else
	char inFileName[] = "blerp.aiff";
#endif
	char outFileName[] = "out-blerp.aiff";

	printf("Running MiniAiff version %s\n(C) S.M.Bernsee - http://www.dspdimension.com\n\n", mAiffGetVersion());

	long channels = mAiffGetNumberOfChannels(inFileName);
	if (channels < 1) {
		printf("File is unreadable or missing, %s\n", inFileName);
		exit(-1);
	}
	float **data = mAiffAllocateAudioBuffer(channels, CHUNK_SIZE);;

	// Read from input file
	printf("Reading from input: %s\n", inFileName);
	ret = mAiffReadData(inFileName, data, 0, CHUNK_SIZE, channels);
	if (ret < 0) {
		printf("! Error reading input file %s - error #%d\n! Wrong format or filename\n", inFileName, ret);
		exit(-1);
	}
	printf("Done reading input file %s\n", inFileName);

	// Create output file
	long wordlength = mAiffGetWordlength(inFileName);
	float sampleRate = (float)mAiffGetSampleRate(inFileName);
	printf("Creating output (sampleRate = %f, wordlength = %d, channels = %d)\n", sampleRate, wordlength, channels);
	ret = mAiffInitFile(outFileName, sampleRate, wordlength, channels);


	// and write stuff to it
	printf("Writing to output: %s\n", outFileName);
	for (long c=0; c < 100; c++) {
		ret = mAiffWriteData(outFileName, data, CHUNK_SIZE, channels);
		printf("...%d written, returned %d\n", c, ret);
		if (ret < 0) {
			printf("! Error writing output file %s - error #%d\n! Wrong format or filename\n", outFileName, ret);
			break;
		}
		//		if (ret < 0) break; 
	}

	mAiffDeallocateAudioBuffer(data, channels);

	// That's all there is to it.
	printf("You're a cool dude now!\n");
	return 0;
}

